@include('partials.header')


@include('partials.navigation')





@yield('content')



@include('partials.footer')