@include('partials.header')


@include('partials.navigation')


@include('partials.messages')


@yield('content')



@include('partials.footer')