<!-- Main header start -->
<header class="main-header">
    <div class="container">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="navbar-header">
                <div class="navbar-header">
                    <button class="w3-button w3-teal w3-xlarge w3-right hidden-lg hidden-md" onclick="openRightMenu()">&#9776;</button>
                    <a href="<?php echo e(route('hola')); ?>" class="logo"> <img src="<?php echo e(asset('front/img/footer-logo.png')); ?>" alt="logo"> </a>
                </div>
                
                    

                
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse collapse" role="navigation" aria-expanded="true" id="app-navigation">

                <ul class="nav navbar-nav navbar-right rightside-navbar">
                    
                    <li> <a href="<?php echo e(route('add-building')); ?>" class="sign-in" style="color: black !important;"> <i class="fa fa-list" aria-hidden="true"></i>LIsting</a> </li>
                    <li>
                    
                    <li>
                        
                    </li>

                </ul>
            </div>
            <!-- /.navbar-collapse -->
            <!-- /.container -->
        </nav>
    </div>
</header>
<!-- Main header end -->