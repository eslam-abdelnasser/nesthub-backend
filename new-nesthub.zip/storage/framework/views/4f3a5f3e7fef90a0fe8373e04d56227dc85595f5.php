<?php $__env->startSection('content'); ?>

    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-md-12" >
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>

            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h3><b>Add Building</b></h3>
                </div>
                
                    
                
            </div>

        </div>

    </div>
    <!-- end feature building-->
    <!-- start tabs of building-->
    <div class="tab">
        <div class="container">
            <div class="row">
                <div class="wizard">

                    <ul class="nav nav-wizard">

                        <li class="active">
                            <a href="#step1" data-toggle="tab">BASIC INFO</a>
                        </li>

                        <li class="disabled">
                            <a href="#step2" data-toggle="tab">OFFICES</a>
                        </li>

                        <li class="disabled">
                            <a href="#step3" data-toggle="tab">IMAGES</a>
                        </li>

                        <li class="disabled">
                            <a href="#step4" data-toggle="tab">ADDITIONAL</a>
                        </li>
                    </ul>
                    
                        <div class="tab-content">

                            <form action="<?php echo e(route('post.building')); ?>" data-parsley-validate="" method="post" id="form_building">
                                <?php echo csrf_field(); ?>

                                <div class="tab-pane active" id="step1">
                                    <div class="container">
                                        <div class="row">
                                            <div class=" name col-md-12 col-sm-12">
                                                <small><b>BUILDING NAME*</b></small>
                                                <p>Tenants will be able to search for you by this name.</p>
                                                <input type="text" id="name" name="name" placeholder="Enter  Building name........" required="true">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class=" address col-md-8 col-sm-8">
                                                <small><b>FULL ADDRESS*</b></small>
                                                <p>Number and Street Address</p>
                                                <input type="text" id="address" name="full_address" placeholder="Enter  Building Address......." required="true">
                                            </div>
                                            <div class=" postal col-md-4 col-sm-4">
                                                <small><b>Postcode</b></small>
                                                <input type="text" id="postal" name="postcode" size="8" placeholder="EX. AA9-AAAA" required="true">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="welcom-message col-md-8 col-sm-8">
                                                <small><b>WELCOME MESSAGE*</b></small>
                                                <p>Give prospective tenants an introduction to your space.</p>
                                                <textarea id="text1" name="welcome_message" required="true"></textarea>
                                            </div>
                                            <div class="tips col-md-4 col-sm-4">
                                                <b>Some Tips</b>
                                                <p>- Give it some personality!</p>
                                                <p>- Describe what kind of companies would be best suited for your space. </p>
                                                <p>- Include any social or work events you organise.</p>
                                                <p>- Do not include information on price and availiblity. This comes later.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="about-us col-md-8 col-sm-8">
                                                <small><b>ABOUT US</b></small>
                                                <p>Tell us more about you as a company.</p>
                                                <textarea name="about_us" required="true"></textarea>
                                            </div>
                                            <div class=" tips col-md-4 col-sm-4">

                                                <b>Some Tips</b>
                                                <p>- What kind of company are you?</p>
                                                <p>- What is your vision and mission? What are your values?</p>
                                                <p>- How would you describe the culture of your space?</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class=" facilities col-md-12 col-sm-12">
                                                <small><b>FACILITIES*</b></small>
                                                <p>Select all available facilities in your building.</p>
                                            </div>
                                        </div>
                                        <div class="checking">
                                            <div class="row">
                                                <div class="col-md-3 col-sm-6">
                                                    <input type="checkbox" name="facilities[]" value="furniture" class="cb" id="check1">
                                                    <label> Furniture</label><hr></br>
                                                    <input type="checkbox" nama="facilities[]" value="pets-allowed" class="cb" id="check2">
                                                    <label>Pets Allowed </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="kitchen" class="cb" id="check3">
                                                    <label>Kitchen</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="cleaning" class="cb" id="check4">
                                                    <label>Cleaning </label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="phone-booths" class="cb" id="check5">
                                                    <label> Phone Booths</label><hr> </br>
                                                    <input type="checkbox"  name="furniture[]" value="utilities" class="cb" id="check6">
                                                    <label> Utilities </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="fruit&snacks" class="cb" id="check7">
                                                    <label> Fruit & Snacks </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="24hr-access" class="cb" id="check8">
                                                    <label> 24 hr Access </label><hr></br>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <input type="checkbox" name="facilities[]" value="breakout-space" class="cb" id="check9">
                                                    <label> Breakout Space</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="lockers" class="cb" id="check10">
                                                    <label> Lockers</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]"  value="bike-storage"  class="cb" id="check11">
                                                    <label> Bike Storage </label><hr></br>
                                                    <input type="checkbox"  name="facilities[]"  value="gym" class="cb" id="check12">
                                                    <label> Gym </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="printing" class="cb" id="check13">
                                                    <label> Printing </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="cafe" class="cb" id="check14">
                                                    <label> Cafe </label><hr></br>
                                                    <input type="checkbox" name="facilities[]"  value="coffee-tea" class="cb" id="check15">
                                                    <label> Coffee & Tea </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="roof-terrace" class="cb" id="check16">
                                                    <label> Roof Terrace</label><hr> </br>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <input type="checkbox" name="facilities[]" value="mailing-address" class="cb" id="check17">
                                                    <label> Mailing Address</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="showers" class="cb" id="check18">
                                                    <label> Showers </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="event-space" class="cb" id="check19">
                                                    <label> Event Space </label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="inventory-storage" class="cb" id="check20">
                                                    <label> Inventory Storage</label><hr></br>
                                                    <input type="checkbox" name="facilities[]"  value="reception" class="cb" id="check21">
                                                    <label> Reception</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="trading-address" class="cb" id="check22">
                                                    <label>  Trading Address</label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="events-talks" class="cb" id="check23">
                                                    <label>Events & Talks</label><hr></br>
                                                </div>
                                                <div class="col-md-3 col-sm-6">
                                                    <input type="checkbox" name="facilities[]" value="disabled-access" class="cb" id="check24">
                                                    <label>Disabled Access</label><hr> </br>
                                                    <input type="checkbox" name="facilities[]" value="meeting-rooms" class="cb" id="check25">
                                                    <label>Meeting Rooms </label> <hr></br>
                                                    <input type="checkbox" name="facilities[]" value="childcare" class="cb" id="check26">
                                                    <label>Childcare</label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="parking" class="cb" id="check27">
                                                    <label>Parking</label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="secure-access" class="cb" id="check28">
                                                    <label>Secure Access</label><hr>  </br>
                                                    <input type="checkbox" name="facilities[]" value="beer-wine" class="cb" id="check29">
                                                    <label>Beer & Wine</label><hr></br>
                                                    <input type="checkbox" name="facilities[]" value="wifi" class="cb" id="check30">
                                                    <label> Wifi </label><hr></br>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                           <!--end tab-->

                            
                                
                                    
                                        
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                        
                                                    
                                                    
                                                        

                                                            

                                                            
                                                            
                                                                
                                                                        
                                                                
                                                                        
                                                                
                                                                        
                                                                        
                                                            

                                                            
                                                                
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                
                                                                
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                
                                                                
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                    
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                        
                                                                            
                                                                            
                                                                            
                                                                        
                                                                    
                                                                
                                                                
                                                                    
                                                                    
                                                                
                                                            
                                                            
                                                        
                                                    
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                
                            

                            
                                
                                    
                                        
                                            
                                                
                                                    
                                                        
                                                        
                                                        

                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                
                                                            
                                                        
                                                    
                                                
                                            
                                        
                                        
                                            

                                                
                                                    
                                                    
                                                        
                                                        
                                                        
                                                        
                                                    
                                                    
                                                

                                            
                                        
                                    
                                

                            
                            
                                
                                
                                    
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                        

                                    
                                

                                
                            
                            <div class="clearfix"></div>
                        </div>
                    
                </div>

            </div>
        </div>
    </div>
    <!-- end building tabs-->
    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6" >
                    <br>
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>
                <div class="col-md-6 col-sm-6">
                    <button class="btn btn-danger Continue" id="Continue">Save&Continue</button>
                </div>
            </div>


        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- end feature building-->





<script type="text/javascript" >

    $('.Continue').click(function () {
        $('#form_building').submit();
    });

</script>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>