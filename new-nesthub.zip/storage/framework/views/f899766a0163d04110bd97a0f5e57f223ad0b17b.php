<?php $__env->startSection('content'); ?>

    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-md-12" >
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>

            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h3><b>Add Building</b></h3>
                </div>
                
                    
                
            </div>

        </div>

    </div>
    <!-- end feature building-->
    <!-- start tabs of building-->
    <div class="tab">
        <div class="container">
            <div class="row">
                <div class="wizard">

                    <ul class="nav nav-wizard">

                        <li class="disabled">
                            <a href="#step1" data-toggle="tab">BASIC INFO</a>
                        </li>

                        <li class="disabled">
                            <a href="#step2" data-toggle="tab">OFFICES</a>
                        </li>

                        <li class="disabled">
                            <a href="#step3" data-toggle="tab">IMAGES</a>
                        </li>

                        <li class="active">
                            <a href="#step4" data-toggle="tab">ADDITIONAL</a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <!--end tab-->

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                            
                                
                                    
                                        
                                            
                                                
                                                    
                                                    
                                                    
                                                    
                                                        
                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                            
                                                        
                                                    
                                                
                                            
                                        
                                    
                                    
                                        

                                            
                                                
                                                
                                                    
                                                    
                                                    
                                                    
                                                
                                                
                                            

                                        
                                    
                                
                            

                        
                        <div class="tab-pane active" id="step4">
                        <!-- start feature building-->
                        <div class="feature-building">
                            <form data-parsley-validate="" method="post" action="<?php echo e(route('post.additional',['id'=>$id])); ?>" id="form-additional">
                                <?php echo csrf_field(); ?>

                                <div class="container">
                                    <div class="row">
                                    <div class=" guid col-md-12 col-md-12" >
                                    <h3>Guidance on listing highlights:</h3>
                                    <p>- Give it some personality!</p>
                                    <p>- What 3 things make your space unique?</p>
                                    <p>- Don't add info about price or availability.</p>
                                    <br>
                                    </div>
                                    </div>
                                    <div class="row">
                                    <div class="highlight col-md-12 col-md-12" >
                                    <small><b>HIGHLIGHT ONE*</b></small>
                                    <p>Title</p>
                                    <input required="" type="text" id="highlight1" name="highlight[]">
                                    <p>Description</p>
                                    <input type="text" required="" id="desc1" name="description[]">
                                    <br>
                                    <br>
                                    <br>
                                    <small><b>HIGHLIGHT Two*</b></small>
                                    <p>Title</p>
                                    <input required="" type="text" id="highlight2_two" name="highlight[]">
                                    <p>Description</p>
                                    <input type="text" required="" id="desc2" name="description[]">
                                    <br>
                                    <br>
                                    <br>
                                    <small><b>HIGHLIGHT Three*</b></small>
                                    <p>Title</p>
                                    <input required="" type="text" id="highlight3" name="highlight[]">
                                    <p>Description</p>
                                    <input type="text" required="" id="desc3" name="description[]">
                                    <br>
                                    <br>
                                    <br>
                                    <small><b>HIGHLIGHT Four*</b></small>
                                    <p>Title</p>
                                    <input required="" type="text" id="highlight4" name="highlight[]">
                                    <p>Description</p>
                                    <input required="" type="text" id="desc4" name="description[]">
                                    <br>
                                    <br>
                                    <br>
                                    <small><b>HIGHLIGHT Five*</b></small>
                                    <p>Title</p>
                                    <input type="text" required="" id="highlight5" name="highlight[]">
                                    <p>Description</p>
                                    <input type="text" required="" id="desc5" name="description[]">
                                    <br>
                                    <br>
                                    <br>
                                    <small><b>EXCLUSIVE OFFER</b></small>
                                    <p>A special offer with Hubble helps you get more prospective tenants (e.g. 10% off your first three months of rent and free welcome breakfast).</p>
                                    <input required="" type="text" id="ExcOffer" name="exlusive_office">
                                    </div>
                                    </div>

                                </div>
                            </form>
                        </div>

                        
                        
                        <div class="clearfix"></div>
                    </div>
                    
                </div>

            </div>
        </div>
    </div>
    <!-- end building tabs-->
    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6" >
                    <br>
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>
                <div class="col-md-6 col-sm-6">
                    <button class="btn btn-danger Continue" id="Continue">Save&Continue</button>
                </div>
            </div>


        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- end feature building-->





    <script type="text/javascript" >

        $('.Continue').click(function () {
            $('#form-additional').submit();
        });

    </script>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>