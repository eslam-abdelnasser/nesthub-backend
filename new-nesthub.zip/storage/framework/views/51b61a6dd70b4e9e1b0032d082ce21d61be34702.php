<?php $__env->startSection('content'); ?>

    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-md-12" >
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>

            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h3><b>Add Building</b></h3>
                </div>
                
                    
                
            </div>

        </div>

    </div>
    <!-- end feature building-->
    <!-- start tabs of building-->
    <div class="tab">
        <div class="container">
            <div class="row">
                <div class="wizard">

                    <ul class="nav nav-wizard">

                        <li class="disabled">
                            <a href="#step1" data-toggle="tab">BASIC INFO</a>
                        </li>

                        <li class="disabled">
                            <a href="#step2" data-toggle="tab">OFFICES</a>
                        </li>

                        <li class="active">
                            <a href="#step3" data-toggle="tab">IMAGES</a>
                        </li>

                        <li class="disabled">
                            <a href="#step4" data-toggle="tab">ADDITIONAL</a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">

                        
                            
                            
                                
                                    
                                        
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                            
                                        
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                            
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                            
                                        
                                        

                                            
                                            
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                    
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                            
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                    
                                
                            
                        
                        <!--end tab-->

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        <div class="tab-pane active" id="step3">
                        <div class="row">
                        <div class="office col-md-12 col-sm-12">
                        <div class="container p-y-1">
                        <div class="row m-b-1">
                        <div class="col-sm-12 offset-sm-12">
                        <div class="form-group inputDnD">
                        <small ><b>IMAGES*</b></small>
                        <p>We recommend you add at least 3 images.</p>
                        <br>
                        <form action="<?php echo e(route('post.images',['id'=>$id])); ?>"  method="post" enctype="multipart/form-data" id="form-upload">
                            <?php echo csrf_field(); ?>

                            <div class="imgUpload" >
                        <div class="form-group">
                        <div class="file-loading">
                        <label>Preview File Icon</label>
                        <input id="file-3" type="file" name="images[]" multiple>
                        </div>

                            
                        </div>
                        </div>
                        </form>
                        </div>
                        </div>
                        </div>
                        </div>
                        <script type="text/javascript">
                        function readUrl(input) {

                        if (input.files && input.files[0]) {
                        let reader = new FileReader();
                        reader.onload = (e) => {
                        let imgData = e.target.result;
                        let imgName = input.files[0].name;
                        input.setAttribute("data-title", imgName);
                        console.log(e.target.result);
                        }
                        reader.readAsDataURL(input.files[0]);
                        }

                        }
                        </script>
                        </div>
                        </div>

                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        

                        
                        
                        <div class="clearfix"></div>
                    </div>
                    
                </div>

            </div>
        </div>
    </div>
    <!-- end building tabs-->
    <!-- start feature building-->
    <div class="feature-building">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6" >
                    <br>
                    <a href="Listing.html"><i class="fa fa-arrow-left" aria-hidden="true"></i> Go To Building</a>
                </div>
                <div class="col-md-6 col-sm-6">
                    <button class="btn btn-danger Continue" id="Continue">Save&Continue</button>
                </div>
            </div>


        </div>
    </div>
    <br>
    <br>
    <br>
    <!-- end feature building-->





    <script type="text/javascript" >

        $('.Continue').click(function () {
            $('#form-upload').submit();
        });

    </script>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>