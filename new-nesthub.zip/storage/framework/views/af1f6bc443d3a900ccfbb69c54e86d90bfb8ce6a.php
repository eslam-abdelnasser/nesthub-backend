<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 200px;">
        <div class="row">

            <div class="col-md-9">
                <?php if(count($buildings)): ?>
                <ul>


                   <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($building->name); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
                <?php else: ?>
                    <h1> no building added</h1>
                <?php endif; ?>
            </div>
            <div class="col-md-3">

                <h5>Hello: <?php echo e(Auth::user()->name); ?></h5>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>